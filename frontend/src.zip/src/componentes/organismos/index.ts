/**
 * index.ts — Exportaciones de componentes organismos
 */

export { FormularioAnalisis } from './FormularioAnalisis';
export { ResultadoAnalisis } from './ResultadoAnalisis';
export { TarjetaProbabilidad } from './TarjetaProbabilidad';
export { ListaRazones } from './ListaRazones';
export { AnalisisMercadoCard } from './AnalisisMercadoCard';
export { Encabezado } from './Encabezado';
export { HistorialEquipo } from './HistorialEquipo';
export { TablaEstadisticasEquipos } from './TablaEstadisticasEquipos';
export { FormularioGuardarApuesta } from './FormularioGuardarApuesta';
export { FiltrosApuestas } from './FiltrosApuestas';
export { ListaApuestas } from './ListaApuestas';
export { ListaBitacoraUnificada } from './ListaBitacoraUnificada';
export { TarjetaCombinada } from './TarjetaCombinada';
export { ListaSelecciones } from './ListaSelecciones';
export { TarjetaApuestaSimple } from './TarjetaApuestaSimple';
export { GraficoCurvaCalibracion } from './GraficoCurvaCalibracion';
export { CreadorCombinada } from './CreadorCombinada';

// ══════════════════════════════════════════════════════════════
// Fase 3: Componentes de contexto y forma
// ══════════════════════════════════════════════════════════════

export { SeccionH2H } from './SeccionH2H';
export { SeccionFormaReciente } from './SeccionFormaReciente';

// ══════════════════════════════════════════════════════════════
// Historial Detallado: Paneles de historial por equipo
// ══════════════════════════════════════════════════════════════

export { PanelHistorialEquipo } from './PanelHistorialEquipo';
export { SeccionHistorialDetallado } from './SeccionHistorialDetallado';

// ══════════════════════════════════════════════════════════════
// Módulo de Fútbol: Componentes específicos para fútbol
// ══════════════════════════════════════════════════════════════

export { ListaPartidosFutbol } from './ListaPartidosFutbol';
export { ComparativaEquipos } from './ComparativaEquipos';
export { GraficoDistribucion } from './GraficoDistribucion';
export { FormularioApuestaFutbol } from './FormularioApuestaFutbol';
export type { DatosApuestaFutbol } from './FormularioApuestaFutbol';
export { ModalGuardarApuestaFutbol } from './ModalGuardarApuestaFutbol';
export { PanelAnalisisFutbol } from './PanelAnalisisFutbol';
export { PanelH2HFutbol } from './PanelH2HFutbol';
export { PanelHistorialEquipoFutbol } from './PanelHistorialEquipoFutbol';
export { PanelAnalisisMercadoFutbol } from './PanelAnalisisMercadoFutbol';
export { TarjetaMercadoFutbol } from './TarjetaMercadoFutbol';
export { TarjetaRecomendacion, ListaRecomendaciones } from './TarjetaRecomendacion';
export { ResumenMetricasFutbol } from './ResumenMetricasFutbol';
